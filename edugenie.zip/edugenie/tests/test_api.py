"""
tests/test_api.py
------------------
Functional tests for every EduGenie endpoint.

Run with:
    pytest tests/test_api.py -v

These tests use FastAPI's TestClient (backed by `requests`/`httpx`), so
they don't need a running `uvicorn` server. They also don't require a
real Ollama daemon or OpenAI key: ai_models.py degrades gracefully to a
labeled stub response when a backend is unavailable, and these tests
only check the *shape* of each response, not the exact wording, so they
pass in that fallback mode too.
"""

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from fastapi.testclient import TestClient  # noqa: E402
from main import app  # noqa: E402

client = TestClient(app)


def test_root_health_check():
    resp = client.get("/")
    assert resp.status_code == 200
    body = resp.json()
    assert body["status"] == "ok"


def test_ask_returns_answer():
    resp = client.post(
        "/ask", json={"question": "What is a variable?", "context": None}
    )
    assert resp.status_code == 200
    body = resp.json()
    assert body["question"] == "What is a variable?"
    assert isinstance(body["answer"], str)
    assert len(body["answer"]) > 0


def test_ask_rejects_empty_question():
    resp = client.post("/ask", json={"question": "   "})
    assert resp.status_code == 400


def test_explain_returns_explanation():
    resp = client.get("/explain", params={"concept": "recursion"})
    assert resp.status_code == 200
    body = resp.json()
    assert body["concept"] == "recursion"
    assert isinstance(body["explanation"], str)
    assert len(body["explanation"]) > 0


def test_quiz_returns_requested_number_of_questions_or_fallback():
    resp = client.post(
        "/quiz",
        json={"topic": "Photosynthesis", "num_questions": 3, "question_type": "multiple_choice"},
    )
    assert resp.status_code == 200
    body = resp.json()
    assert body["topic"] == "Photosynthesis"
    assert isinstance(body["questions"], list)
    assert len(body["questions"]) >= 1
    q = body["questions"][0]
    assert "question" in q and "answer" in q and "options" in q


def test_quiz_validates_num_questions_range():
    resp = client.post(
        "/quiz", json={"topic": "Math", "num_questions": 999, "question_type": "multiple_choice"}
    )
    assert resp.status_code == 422  # Pydantic range validation (le=20)


def test_summarize_returns_summary_and_word_counts():
    text = "The water cycle describes how water moves through Earth's systems. " * 5
    resp = client.post("/summarize", json={"text": text, "max_sentences": 3})
    assert resp.status_code == 200
    body = resp.json()
    assert isinstance(body["summary"], str) and len(body["summary"]) > 0
    assert body["original_length_words"] > 0
    assert body["summary_length_words"] > 0


def test_summarize_rejects_empty_text():
    resp = client.post("/summarize", json={"text": "", "max_sentences": 3})
    assert resp.status_code == 422  # Pydantic min_length validation


def test_learnpath_returns_stages():
    resp = client.get("/learnpath", params={"topic": "SQL"})
    assert resp.status_code == 200
    body = resp.json()
    assert body["subject"] == "SQL"
    assert isinstance(body["stages"], list)
    assert len(body["stages"]) >= 1
    stage = body["stages"][0]
    assert "stage" in stage and "topics" in stage and "resources" in stage


def test_learnpath_rejects_empty_topic():
    resp = client.get("/learnpath", params={"topic": " "})
    assert resp.status_code == 400


def test_frontend_is_served():
    resp = client.get("/app")
    assert resp.status_code == 200
    assert "EduGenie" in resp.text


def test_openapi_docs_available():
    resp = client.get("/docs")
    assert resp.status_code == 200
