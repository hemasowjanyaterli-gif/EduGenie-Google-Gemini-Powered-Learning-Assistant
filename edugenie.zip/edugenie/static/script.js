// script.js
// Handles tab switching and wires each form to its FastAPI endpoint via
// fetch(). The API is assumed to be served from the same origin (FastAPI
// serves this file too), so relative URLs like "/ask" work as-is.
// If you deploy the frontend separately from the backend, change
// API_BASE below to the backend's full URL.

const API_BASE = "";

function $(sel, root = document) {
  return root.querySelector(sel);
}
function $all(sel, root = document) {
  return Array.from(root.querySelectorAll(sel));
}

// ---- Tab switching --------------------------------------------------

function initTabs() {
  const tabs = $all(".tab");
  const panels = $all(".panel");
  tabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      tabs.forEach((t) => t.classList.remove("active"));
      panels.forEach((p) => p.classList.remove("active"));
      tab.classList.add("active");
      $(`#panel-${tab.dataset.panel}`).classList.add("active");
    });
  });
}

// ---- Helpers ----------------------------------------------------------

function setLoading(resultEl, message) {
  resultEl.innerHTML = `<div class="loading">${message}</div>`;
}

function setError(resultEl, err) {
  resultEl.innerHTML = `<div class="error">Something went wrong: ${String(err)}</div>`;
}

async function postJSON(path, body) {
  const res = await fetch(`${API_BASE}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const detail = await res.text();
    throw new Error(`${res.status} ${res.statusText} — ${detail}`);
  }
  return res.json();
}

async function getJSON(path) {
  const res = await fetch(`${API_BASE}${path}`);
  if (!res.ok) {
    const detail = await res.text();
    throw new Error(`${res.status} ${res.statusText} — ${detail}`);
  }
  return res.json();
}

// ---- Ask ---------------------------------------------------------------

function initAsk() {
  const form = $("#form-ask");
  const result = $("#result-ask");
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const question = $("#ask-question").value.trim();
    const context = $("#ask-context").value.trim();
    if (!question) return;
    setLoading(result, "Thinking…");
    try {
      const data = await postJSON("/ask", { question, context: context || null });
      result.innerHTML = `<div class="answer-block">${escapeHtml(data.answer)}</div>`;
    } catch (err) {
      setError(result, err);
    }
  });
}

// ---- Explain -------------------------------------------------------------

function initExplain() {
  const form = $("#form-explain");
  const result = $("#result-explain");
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const concept = $("#explain-concept").value.trim();
    if (!concept) return;
    setLoading(result, "Explaining…");
    try {
      const data = await getJSON(`/explain?concept=${encodeURIComponent(concept)}`);
      result.innerHTML = `<div class="answer-block">${escapeHtml(data.explanation)}</div>`;
    } catch (err) {
      setError(result, err);
    }
  });
}

// ---- Quiz ------------------------------------------------------------

function initQuiz() {
  const form = $("#form-quiz");
  const result = $("#result-quiz");
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const topic = $("#quiz-topic").value.trim();
    const num_questions = parseInt($("#quiz-num").value, 10) || 5;
    const question_type = $("#quiz-type").value;
    if (!topic) return;
    setLoading(result, "Writing quiz questions…");
    try {
      const data = await postJSON("/quiz", { topic, num_questions, question_type });
      result.innerHTML = data.questions
        .map(
          (q, i) => `
        <div class="quiz-q">
          <span class="qnum">Question ${i + 1}</span>
          <div>${escapeHtml(q.question)}</div>
          ${
            q.options && q.options.length
              ? `<ul>${q.options.map((o) => `<li>${escapeHtml(o)}</li>`).join("")}</ul>`
              : ""
          }
          <div class="ans">Answer: ${escapeHtml(q.answer)}</div>
        </div>`
        )
        .join("");
    } catch (err) {
      setError(result, err);
    }
  });
}

// ---- Summarize --------------------------------------------------------

function initSummarize() {
  const form = $("#form-summarize");
  const result = $("#result-summarize");
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const text = $("#summarize-text").value.trim();
    const max_sentences = parseInt($("#summarize-max").value, 10) || 5;
    if (!text) return;
    setLoading(result, "Summarizing…");
    try {
      const data = await postJSON("/summarize", { text, max_sentences });
      result.innerHTML = `
        <div class="answer-block">${escapeHtml(data.summary)}</div>
        <p class="hint" style="margin-top:10px;">
          ${data.original_length_words} words → ${data.summary_length_words} words
        </p>`;
    } catch (err) {
      setError(result, err);
    }
  });
}

// ---- Learning path ------------------------------------------------------

function initLearnPath() {
  const form = $("#form-learnpath");
  const result = $("#result-learnpath");
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const topic = $("#learnpath-topic").value.trim();
    if (!topic) return;
    setLoading(result, "Building your learning path…");
    try {
      const data = await getJSON(`/learnpath?topic=${encodeURIComponent(topic)}`);
      result.innerHTML = data.stages
        .map(
          (s) => `
        <div class="stage">
          <h3>${escapeHtml(s.stage)}</h3>
          <strong>Topics</strong>
          <ul>${s.topics.map((t) => `<li>${escapeHtml(t)}</li>`).join("")}</ul>
          <strong>Resources</strong>
          <ul>${s.resources.map((r) => `<li>${escapeHtml(r)}</li>`).join("")}</ul>
        </div>`
        )
        .join("");
    } catch (err) {
      setError(result, err);
    }
  });
}

// ---- Utility ------------------------------------------------------------

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str ?? "";
  return div.innerHTML;
}

// ---- Init ----------------------------------------------------------------

document.addEventListener("DOMContentLoaded", () => {
  initTabs();
  initAsk();
  initExplain();
  initQuiz();
  initSummarize();
  initLearnPath();
});
