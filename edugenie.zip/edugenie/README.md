# EduGenie

A lightweight AI-powered educational assistant: question answering, concept
explanation, quiz generation, text summarization, and personalized learning
paths — built on a **FastAPI** backend and a responsive **HTML/CSS/JS**
frontend, designed to run comfortably on a Mac with an M1 chip.

---

## 1. ER Diagram (Database Schema)

This build uses AI calls per-request rather than persistent storage, so no
database is wired up yet — but here is the data model EduGenie would use
once user accounts / history are added (e.g. with SQLite or Postgres):

```
┌────────────────────┐        ┌──────────────────────┐
│        User          │        │        Topic            │
├────────────────────┤        ├──────────────────────┤
│ id (PK)               │        │ id (PK)                 │
│ name                   │        │ name                    │
│ email                  │        │ description             │
│ created_at             │        └──────────────────────┘
└────────────────────┘                    │ 1
        │ 1                                     │
        │                                        │ N
        │ N                              ┌──────────────────────┐
┌────────────────────┐        │    QuizQuestion         │
│   InteractionLog      │        ├──────────────────────┤
├────────────────────┤        │ id (PK)                 │
│ id (PK)               │        │ topic_id (FK -> Topic) │
│ user_id (FK -> User)   │        │ question_text           │
│ type (ask/explain/     │        │ options (JSON)          │
│   quiz/summarize/      │        │ answer                  │
│   learnpath)           │        └──────────────────────┘
│ prompt_text            │
│ response_text          │        ┌──────────────────────┐
│ created_at             │        │   LearningPath          │
└────────────────────┘        ├──────────────────────┤
                                    │ id (PK)                 │
                                    │ user_id (FK -> User)    │
                                    │ topic_id (FK -> Topic)  │
                                    │ stage (beginner/         │
                                    │   intermediate/advanced) │
                                    │ topics (JSON list)      │
                                    │ resources (JSON list)   │
                                    └──────────────────────┘
```

**Relationships:** one `User` has many `InteractionLog` entries (every
ask/explain/quiz/summarize/learnpath call, for history and analytics) and
many `LearningPath` records. `Topic` is shared across `QuizQuestion` and
`LearningPath` so quizzes and paths on the same subject can be cross-linked.

---

## 2. Links (Resources)

- FastAPI docs: https://fastapi.tiangolo.com/
- Pydantic docs: https://docs.pydantic.dev/
- Uvicorn docs: https://www.uvicorn.org/
- Ollama (local LLM runner): https://ollama.com/
- OpenAI API reference: https://platform.openai.com/docs/api-reference
- MDN — Responsive Design: https://developer.mozilla.org/en-US/docs/Learn/CSS/CSS_layout/Responsive_Design
- MDN — Fetch API: https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API

---

## 3. Project Workflow

```
 ┌──────────┐    fetch()     ┌───────────────┐   generate()   ┌────────────────┐
 │ Frontend    │  ───────────▶ │ FastAPI backend  │  ─────────────▶ │  ai_models.py     │
 │ (index.html,│                │  (main.py)          │                 │  routing layer     │
 │  script.js) │  ◀─────────── │  validates via     │  ◀───────────── │                    │
 └──────────┘   JSON response │  Pydantic models   │   text/JSON     └────────┬───────┘
                                    └───────────────┘                          │
                                                                                      ▼
                                                                  ┌────────────────────────┐
                                                                  │ local (Ollama, quantized) │
                                                                  │      or cloud (OpenAI)     │
                                                                  └────────────────────────┘
```

1. The user interacts with a tab in the browser (Ask / Explain / Quiz /
   Summarize / Learning path).
2. `script.js` sends a `fetch()` call — `POST` for `/ask`, `/quiz`,
   `/summarize`; `GET` for `/explain`, `/learnpath`.
3. FastAPI validates the request against a Pydantic model, builds a prompt,
   and calls `ai_models.generate()` (or `generate_json()` for structured
   responses like quizzes and learning paths).
4. `ai_models.py` routes the call to a **local** quantized model (via
   Ollama) or a **cloud** model (OpenAI), based on `MODEL_ROUTES`.
5. The response is validated against a Pydantic response model and
   returned as JSON.
6. The frontend renders it into the active panel.

---

## 4. Select AI Models

| Feature      | Default backend | Why                                                                 |
|--------------|------------------|----------------------------------------------------------------------|
| `/ask`         | local             | Short Q&A doesn't need frontier reasoning; local keeps latency low.  |
| `/explain`     | local             | Same — short, single-concept explanations.                           |
| `/quiz`        | cloud             | Needs reliably well-formed structured JSON output across many items. |
| `/summarize`   | local             | Summaries are short-context; a quantized 7-8B model handles this well.|
| `/learnpath`   | cloud             | Multi-stage structured plan benefits from stronger reasoning.        |

- **Local model:** a quantized 7–8B instruction model (e.g.
  `llama3:8b-instruct-q4_0`) served by **Ollama**. Apple Silicon's unified
  memory means the GPU can access the same RAM as the CPU, so a Mac with
  16–32 GB comfortably runs a Q4-quantized 7–13B model with no dedicated
  VRAM bottleneck. This is fast, free, private, and works offline.
- **Cloud model:** OpenAI `gpt-4o-mini` by default (configurable). Used
  where structure and reasoning quality matter more than raw speed.
- **Trade-off:** local = fast/free/offline but weaker at long structured
  output; cloud = stronger but costs money, needs network, and has higher
  latency. `ai_models.py` lets you override everything with
  `AI_BACKEND=local` or `AI_BACKEND=cloud` for a fully offline demo.

---

## 5. Module Implementation

| Module              | File            | Responsibility                                                                 |
|----------------------|-----------------|-----------------------------------------------------------------------------------|
| `qa_module`            | `main.py` (`/ask`, `/explain`) | Builds a tutor-style prompt from the question/concept (+ optional context) and returns the model's text answer. |
| `quiz_module`          | `main.py` (`/quiz`)             | Builds a JSON-structured prompt for N quiz questions and parses the model's JSON response into `QuizQuestion` objects. |
| `summarizer_module`    | `main.py` (`/summarize`)        | Builds a "summarize in at most N sentences" prompt and returns text + word-count metadata. |
| `path_recommender`     | `main.py` (`/learnpath`)        | Builds a JSON-structured prompt for a 3-stage curriculum and parses it into `LearnPathStage` objects. |
| `ai_models`            | `ai_models.py`                    | Backend-agnostic routing layer: picks local (Ollama) vs cloud (OpenAI) per feature, degrades gracefully if a backend is unavailable, and provides `generate()` / `generate_json()`. |

Each endpoint module follows the same pattern: **validate input (Pydantic)
→ build a prompt → call `ai_models` → validate/shape the output (Pydantic)
→ return JSON.**

---

## 6. Backend API with FastAPI

See `main.py`. Endpoints:

- `POST /ask` — question + optional context → answer
- `GET /explain?concept=...` → explanation
- `POST /quiz` — topic, num_questions, question_type → structured quiz
- `POST /summarize` — text, max_sentences → summary + word counts
- `GET /learnpath?topic=...` → staged learning path

Interactive Swagger docs are auto-generated at **`/docs`** (and ReDoc at
**`/redoc`**) as soon as the server is running.

---

## 7. Build Web Interface

See `static/index.html`, `static/style.css`, `static/script.js`. A single
tabbed page ("the study desk" visual identity — index-card panels, a
marker-yellow accent, monospace notebook labels) covers all five features,
built with CSS for mobile/tablet/desktop responsiveness (flex layouts,
`clamp()` type sizing, a stacked layout under 640px).

---

## 8. Live Integration

FastAPI serves the frontend directly via `StaticFiles`, so backend and
frontend run from a single process:

- `static/` is mounted at `/static`
- `GET /app` returns `static/index.html`
- `script.js` calls the API with relative paths (`/ask`, `/quiz`, etc.), so
  no CORS configuration is needed when served this way. (`CORSMiddleware`
  is included in `main.py` in case you serve the frontend separately.)

No Docker is required for local use, but if you want containerized
deployment:

```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

---

## 9. Run Locally

```bash
# 1. Create and activate a virtual environment (recommended)
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. (Optional) configure AI backends
export OPENAI_API_KEY="sk-..."          # for cloud features (quiz, learnpath)
export OLLAMA_MODEL="llama3:8b-instruct-q4_0"   # local model name
# ollama pull llama3:8b-instruct-q4_0   # once, if using local features
# ollama serve                            # run the local model daemon

# Force everything to one backend (handy for an offline demo):
# export AI_BACKEND=local
# export AI_BACKEND=cloud

# 4. Run the server
uvicorn main:app --reload

# 5. Open the app
#    Frontend:      http://127.0.0.1:8000/app
#    API docs:       http://127.0.0.1:8000/docs
```

If neither Ollama nor an OpenAI key is configured, every endpoint still
returns a valid, well-formed response — it will just include a
`[local-model-unavailable]` / `[cloud-model-unavailable]` label so you can
see exactly what to configure.

---

## 10. Functional Testing

```bash
pytest tests/test_api.py -v
```

`tests/test_api.py` uses FastAPI's `TestClient` to call every endpoint and
check response shape and status codes — including validation failures
(empty question, out-of-range quiz size, empty summarize text). Tests pass
whether or not a real AI backend is configured, since they check structure,
not exact wording.

**Manual UI testing checklist:**
- [ ] Load `/app` — all 5 tabs render and switch correctly
- [ ] Ask a question → answer block appears
- [ ] Explain a concept → explanation block appears
- [ ] Generate a quiz → questions + options + answers render
- [ ] Summarize a pasted paragraph → summary + word counts render
- [ ] Build a learning path → 3 stages with topics/resources render
- [ ] Resize the browser to a phone width → layout stacks cleanly

---

## 11. Conclusion

EduGenie delivers all five requested capabilities — question answering,
concept explanation, quiz generation, summarization, and personalized
learning paths — behind a clean FastAPI backend and a single responsive
frontend, with a hybrid local/cloud model strategy tuned for resource-
constrained hardware like an M1 Mac. The AI layer (`ai_models.py`) is
intentionally decoupled from the endpoints, so swapping in a different
local runtime (e.g. `llama.cpp` directly) or a different cloud provider
(e.g. Anthropic's Claude API) only requires editing one file.

**Future enhancements:**
- Add the `User` / `InteractionLog` persistence layer from the ER diagram
  above (SQLite for local use, Postgres for production) to support login,
  history, and progress tracking.
- Stream responses token-by-token (FastAPI `StreamingResponse`) for a more
  responsive UI on longer generations.
- Add spaced-repetition scheduling on top of the quiz module.
- Fine-tune or prompt-tune the local model specifically for quiz-JSON
  reliability, to reduce reliance on the cloud model for that feature.
