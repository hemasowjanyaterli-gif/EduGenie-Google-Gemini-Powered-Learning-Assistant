"""
ai_models.py
------------
Thin abstraction layer over the two AI "backends" EduGenie can call:

1. LOCAL   -> a small, quantized open-source model served by Ollama
              (e.g. llama3:8b-instruct-q4_0, phi3:mini, etc.) running
              on-device. Good for Apple Silicon (M1/M2) because Ollama
              uses the unified-memory GPU path via Metal, and quantized
              7-8B models comfortably fit in 16 GB of RAM.
2. CLOUD   -> a larger hosted model (OpenAI GPT-4o-mini / GPT-4o, or
              Anthropic Claude) used for tasks that need more reasoning
              quality: longer summaries, nuanced explanations, and
              multi-step learning-path generation.

Why a hybrid split?
  * Local models are fast, private, and free to run, but weaker at
    long-context reasoning and structured multi-part answers.
  * Cloud models are stronger but cost money/latency and need network
    access + an API key.

EduGenie picks a backend per-feature in `MODEL_ROUTES` below. You can
override the default routing with the AI_BACKEND env var
("local" | "cloud") to force everything one way, which is handy for
offline demos on a Mac with no internet connection.

None of the functions here raise on a missing API key / missing Ollama
daemon -- they fall back to a clearly-labeled canned response so the
rest of the app (and the test suite) still works with zero external
services configured.
"""

from __future__ import annotations

import os
import json
import textwrap
from typing import Optional

# --------------------------------------------------------------------------
# Configuration
# --------------------------------------------------------------------------

# Which backend each feature prefers by default. "local" keeps things fast
# and free; "cloud" is used where answer quality matters more than latency.
MODEL_ROUTES = {
    "ask": "local",  # quick Q&A -> local model is usually good enough
    "explain": "local",  # short concept explanations -> local model
    "quiz": "cloud",  # needs structured, well-formed JSON -> cloud model
    "summarize": "local",  # short-to-medium summaries -> local model
    "learnpath": "cloud",  # multi-stage structured plan -> cloud model
}

# Force everything to one backend regardless of MODEL_ROUTES, e.g. for a
# fully offline demo: `export AI_BACKEND=local`
FORCE_BACKEND = os.getenv("AI_BACKEND")  # "local" | "cloud" | None

OLLAMA_HOST = os.getenv("OLLAMA_HOST", "http://localhost:11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3:8b-instruct-q4_0")

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")


# --------------------------------------------------------------------------
# Low-level backend callers
# --------------------------------------------------------------------------

def _call_local_model(prompt: str, system: Optional[str] = None) -> str:
    """
    Call a local quantized LLM served by Ollama (https://ollama.com).

    Requires `ollama serve` running and a model pulled, e.g.:
        ollama pull llama3:8b-instruct-q4_0

    Falls back to a labeled stub if the `requests` package or the Ollama
    daemon isn't available, so the API keeps working in dev/test.
    """
    try:
        import requests  # local import: optional dependency

        payload = {
            "model": OLLAMA_MODEL,
            "prompt": prompt if not system else f"{system}\n\n{prompt}",
            "stream": False,
        }
        resp = requests.post(f"{OLLAMA_HOST}/api/generate", json=payload, timeout=60)
        resp.raise_for_status()
        data = resp.json()
        return data.get("response", "").strip()
    except Exception as exc:  # noqa: BLE001 - we want to degrade gracefully
        return (
            "[local-model-unavailable] Could not reach Ollama at "
            f"{OLLAMA_HOST} ({exc}). Start it with `ollama serve` and "
            f"`ollama pull {OLLAMA_MODEL}`, or set AI_BACKEND=cloud.\n\n"
            f"-- Stub response for prompt --\n{textwrap.shorten(prompt, 200)}"
        )


def _call_cloud_model(prompt: str, system: Optional[str] = None) -> str:
    """
    Call a cloud model (OpenAI Chat Completions API by default).

    Requires OPENAI_API_KEY to be set in the environment. Falls back to a
    labeled stub if the key is missing or the request fails, so the app
    still runs (e.g. for local demos / tests without network access).
    """
    if not OPENAI_API_KEY:
        return (
            "[cloud-model-unavailable] OPENAI_API_KEY is not set. "
            "Set it in your environment (see README) or use AI_BACKEND=local.\n\n"
            f"-- Stub response for prompt --\n{textwrap.shorten(prompt, 200)}"
        )

    try:
        import requests  # local import: optional dependency

        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        resp = requests.post(
            "https://api.openai.com/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {OPENAI_API_KEY}",
                "Content-Type": "application/json",
            },
            json={"model": OPENAI_MODEL, "messages": messages, "temperature": 0.4},
            timeout=60,
        )
        resp.raise_for_status()
        data = resp.json()
        return data["choices"][0]["message"]["content"].strip()
    except Exception as exc:  # noqa: BLE001
        return (
            f"[cloud-model-error] {exc}\n\n"
            f"-- Stub response for prompt --\n{textwrap.shorten(prompt, 200)}"
        )


# --------------------------------------------------------------------------
# Public entry point
# --------------------------------------------------------------------------

def generate(feature: str, prompt: str, system: Optional[str] = None) -> str:
    """
    Route a prompt to the right backend for the given feature name
    ("ask", "explain", "quiz", "summarize", "learnpath") and return the
    raw text response.
    """
    backend = FORCE_BACKEND or MODEL_ROUTES.get(feature, "local")
    if backend == "cloud":
        return _call_cloud_model(prompt, system=system)
    return _call_local_model(prompt, system=system)


def generate_json(feature: str, prompt: str, system: Optional[str] = None) -> dict:
    """
    Same as `generate`, but asks the model to respond with JSON only and
    parses it. Falls back to a minimal, well-formed stub dict if parsing
    fails, so downstream Pydantic response models never blow up.
    """
    json_instructions = (
        "Respond with ONLY valid JSON. No markdown fences, no commentary, "
        "no preamble."
    )
    full_system = f"{system}\n{json_instructions}" if system else json_instructions
    raw = generate(feature, prompt, system=full_system)

    cleaned = raw.strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.strip("`")
        cleaned = cleaned.replace("json\n", "", 1)

    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        return {"error": "model_did_not_return_valid_json", "raw_response": raw}
